package com.webify.webapp.wlib.palette;

import org.apache.commons.lang.enum.Enum;

/**
 *  Defines different sorting strategies for the {@link Palette}
component.
 *
 *  @author Howard Lewis Ship
 *  @version $Id: Test120.java 15 2008-08-04 22:00:07Z hboutemy $
 *
 **/
public final class Test120 extends Enum {
}
