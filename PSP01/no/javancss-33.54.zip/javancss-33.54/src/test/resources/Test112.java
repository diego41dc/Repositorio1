public class Test112<T> {
    public class Info {
        public String infoType;
    }
}
