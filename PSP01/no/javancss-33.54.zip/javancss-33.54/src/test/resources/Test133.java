public class Test133
{
  private Object convertIntoKnownBaseType( Object toValue, Class businessPropertyType)
  {
               if ((Character.class == businessPropertyType) || (businessPropertyType.class ==businessPropertyType)) //(char.class == businessPropertyType))
                 return null;
               /*if ((char.class == businessPropertyType) {
                 if (businessPropertyType.class ==businessPropertyType) //(char.class == businessPropertyType))
                   return null;
               }*/
if ((1 == 2) || (3 == 4)) return null;
               if (Character.class == businessPropertyType)
                       return null;
               if (char.class == businessPropertyType)
               {
                 if (Character.class == businessPropertyType)
                 {
                       return null;
                 }
               }
               return null;
  }
}
