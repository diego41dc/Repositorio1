public class AssignOperator {

    public static void test() {
        int a;
        int b;
        int c;
        int d;
        a = (b += c - d);
    }

}
