package org.example;

public class ChildTree<K, V> extends ParentTree<K, V> {

   protected class Node extends ParentTree<K,V>.Node {

   }

}
