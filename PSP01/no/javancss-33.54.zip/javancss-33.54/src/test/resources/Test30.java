public class Test30 {
    public static void filter()    {
        int i = 2;
    }
}
