public class Test66
{
    public Test66()
    {
        System.out.println( "test" );
    }
}
