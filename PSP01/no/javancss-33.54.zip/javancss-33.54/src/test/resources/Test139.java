
/**
 * 
 * @author 
 *
 */

public final class TestJavadocConstructor {

	/**
	 * 
	 * @param text
	 */
	public TestJavadocConstructor(final String text){
		
	}
	
	/**
	 * 
	 * @return
	 * @throws Exception
	 */

	public void testMethod() {
		
	}
}
